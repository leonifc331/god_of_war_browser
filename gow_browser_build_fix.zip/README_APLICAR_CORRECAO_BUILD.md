# Correção do build do god_of_war_browser

O log do AppVeyor falha por problemas no `god_of_war_browser.go`, não por causa direta do editor FLP/HUD.

## Erros corrigidos

- `parseCheck redeclared`: existe `parseCheck` em `parsecheck.go` e outro em `god_of_war_browser.go`.
- `entry.Name undefined`: `vfs.Directory.List()` retorna `[]string`, não entries com `.Name()` / `.IsDir()`.
- `GetDirectory/GetFile undefined`: a interface `vfs.Directory` usa `GetElement(name)`.
- `*os.File does not implement vfs.File`: `iso.NewIsoDriver` e `psarc.NewPsarcDriver` esperam `vfs.File`, então deve ser usado `vfs.NewDirectoryDriverFile`.

## Como aplicar

Na raiz do repositório:

```bash
python fix_gow_browser_build.py
gofmt -w god_of_war_browser.go
go test ./...
```

Depois faça commit:

```bash
git add god_of_war_browser.go
git commit -m "Fix browser build after driver setup changes"
git push
```

## Observação

O script cria backup em:

```txt
god_of_war_browser.go.bak
```

Se quiser reverter:

```bash
cp god_of_war_browser.go.bak god_of_war_browser.go
```
