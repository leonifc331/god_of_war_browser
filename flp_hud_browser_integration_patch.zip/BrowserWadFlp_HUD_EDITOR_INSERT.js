        let flp_hud_stage_editor = function() {
            set3dVisible(false);
            gr_instance.cleanup();
            dataSummary.empty();

            let state = {
                timeline: 'root',
                frame: 0,
                zoom: 1.0,
                invertY: true,
                cloneTransformOnDrag: true,
                selectedKey: null,
                selectedItem: null,
                visibleItems: [],
                drag: null,
                patchLog: [],
            };

            let imageCache = {};

            function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
            function n(v, def) { v = Number.parseFloat(v); return Number.isFinite(v) ? v : def; }
            function handlerName(h) {
                if (!h) { return 'null handler'; }
                let name = (objNamesArray && objNamesArray[h.TypeArrayId]) ? objNamesArray[h.TypeArrayId] : ('Type ' + h.TypeArrayId);
                return name + '[' + h.IdInThatTypeArray + ']';
            }
            function getHandlerObjSafe(h) {
                if (!h) { return undefined; }
                if (h.TypeArrayId == 8) { return flpdata.Data8; }
                let arr = get_obj_arr_by_id(h.TypeArrayId);
                if (!arr) { return undefined; }
                return arr[h.IdInThatTypeArray];
            }
            function transformName(id) { return 'Transform[' + id + ']'; }
            function colorName(id) { return 'Color[' + id + ']'; }
            function timelineOptions() {
                let out = [{ id: 'root', label: 'ROOT / Data8', handler: { TypeArrayId: 8, IdInThatTypeArray: 0 }, node: flpdata.Data8 }];
                for (let i = 0; i < flpdata.Datas7.length; i++) {
                    out.push({ id: 'd7:' + i, label: 'Datas7[' + i + ']', handler: { TypeArrayId: 7, IdInThatTypeArray: i }, node: flpdata.Datas7[i] });
                }
                for (let i = 0; i < flpdata.Datas6.length; i++) {
                    out.push({ id: 'd6:' + i, label: 'Datas6[' + i + '].Sub1', handler: { TypeArrayId: 6, IdInThatTypeArray: i }, node: flpdata.Datas6[i].Sub1 });
                }
                return out;
            }
            function currentTimeline() {
                let opts = timelineOptions();
                for (let o of opts) { if (o.id == state.timeline) { return o; } }
                return opts[0];
            }
            function identityTransform() { return { x: 0, y: 0, a: 1, b: 0, c: 0, d: 1 }; }
            function compose2d(parent, t) {
                if (!t) { return parent; }
                let m = t.Matrix || [1, 0, 0, 1];
                let ox = n(t.OffsetX, 0), oy = n(t.OffsetY, 0);
                return {
                    a: parent.a * m[0] + parent.c * m[1],
                    b: parent.b * m[0] + parent.d * m[1],
                    c: parent.a * m[2] + parent.c * m[3],
                    d: parent.b * m[2] + parent.d * m[3],
                    x: parent.x + parent.a * ox + parent.c * oy,
                    y: parent.y + parent.b * ox + parent.d * oy,
                };
            }
            function composeColor(parent, colorId) {
                let c = flpdata.BlendColors[colorId];
                if (!c || !c.Color) { return parent.slice(); }
                return [parent[0] * (c.Color[0] / 256.0), parent[1] * (c.Color[1] / 256.0), parent[2] * (c.Color[2] / 256.0), parent[3] * (c.Color[3] / 256.0)];
            }
            function keyForItem(path, elemIndex, keyIndex) { return path + '/e' + elemIndex + '/k' + keyIndex; }
            function currentKeyFrame(anim, frame) {
                if (!anim || !anim.KeyFrames || anim.KeyFrames.length == 0) { return null; }
                for (let i = 0; i < anim.KeyFrames.length; i++) {
                    if (frame <= anim.KeyFrames[i].WhenThisFrameEnds) { return { key: anim.KeyFrames[i], index: i }; }
                }
                return { key: anim.KeyFrames[anim.KeyFrames.length - 1], index: anim.KeyFrames.length - 1 };
            }
            function firstTextureNameForHandler(h) {
                let obj = getHandlerObjSafe(h);
                if (!obj) { return ''; }
                if (h.TypeArrayId == 1 && obj.Materials) {
                    for (let mat of obj.Materials) { if (mat.TextureName) { return mat.TextureName; } }
                }
                return '';
            }
            function getTextureImage(name) {
                if (!name || !flp.Textures || !flp.Textures[name] || !flp.Textures[name].Images || !flp.Textures[name].Images.length) { return null; }
                if (!imageCache[name]) {
                    let img = new Image();
                    img.src = 'data:image/png;base64,' + flp.Textures[name].Images[0].Image;
                    imageCache[name] = img;
                }
                return imageCache[name];
            }
            function getDisplayLabel(h, key) {
                let obj = getHandlerObjSafe(h);
                if (!obj) { return handlerName(h); }
                if (h.TypeArrayId == 1) {
                    let tx = firstTextureNameForHandler(h);
                    return 'MeshPart ' + obj.MeshPartIndex + (tx ? ' / ' + tx : '');
                }
                if (h.TypeArrayId == 5) { return 'DynLabel ' + (obj.ValueName || obj.Placeholder || h.IdInThatTypeArray); }
                if (h.TypeArrayId == 4) { return 'StaticLabel ' + h.IdInThatTypeArray; }
                if (h.TypeArrayId == 6 || h.TypeArrayId == 7 || h.TypeArrayId == 8) { return handlerName(h) + ' timeline'; }
                return key && key.Name ? key.Name : handlerName(h);
            }
            function collectItemsFromTimeline(node, handler, frame, parentTransform, parentColor, path, depth) {
                let out = [];
                if (!node || !node.ElementsAnimation || depth > 12) { return out; }
                for (let i = 0; i < node.ElementsAnimation.length; i++) {
                    let anim = node.ElementsAnimation[i];
                    let kf = currentKeyFrame(anim, frame);
                    if (!kf || !kf.key) { continue; }
                    let key = kf.key;
                    let worldT = compose2d(parentTransform, flpdata.Transformations[key.TransformationId]);
                    let worldC = composeColor(parentColor, key.ColorId);
                    let item = { id: keyForItem(path, i, kf.index), path: path, elementIndex: i, keyIndex: kf.index, parentHandler: handler, keyFrame: key, elementHandler: key.ElementHandler, transformId: key.TransformationId, colorId: key.ColorId, world: worldT, color: worldC, label: getDisplayLabel(key.ElementHandler, key), depth: depth };
                    out.push(item);
                    let child = getHandlerObjSafe(key.ElementHandler);
                    if (key.ElementHandler.TypeArrayId == 6 && child && child.Sub1) {
                        out = out.concat(collectItemsFromTimeline(child.Sub1, key.ElementHandler, frame, worldT, worldC, item.id, depth + 1));
                    } else if ((key.ElementHandler.TypeArrayId == 7 || key.ElementHandler.TypeArrayId == 8) && child) {
                        out = out.concat(collectItemsFromTimeline(child, key.ElementHandler, frame, worldT, worldC, item.id, depth + 1));
                    }
                }
                return out;
            }
            function collectVisibleItems() {
                let tl = currentTimeline();
                state.visibleItems = collectItemsFromTimeline(tl.node, tl.handler, state.frame, identityTransform(), [1, 1, 1, 1], tl.id, 0);
                if (state.selectedKey && !state.visibleItems.find(i => i.id == state.selectedKey)) { state.selectedKey = null; state.selectedItem = null; }
                if (state.selectedKey) { state.selectedItem = state.visibleItems.find(i => i.id == state.selectedKey); }
            }
            function transformUsageCount(transformId) {
                let count = 0;
                function scanNode(node) {
                    if (!node || !node.ElementsAnimation) { return; }
                    for (let anim of node.ElementsAnimation) { for (let k of anim.KeyFrames) { if (k.TransformationId == transformId) { count++; } } }
                }
                for (let d of flpdata.Datas6) { scanNode(d.Sub1); }
                for (let d of flpdata.Datas7) { scanNode(d); }
                scanNode(flpdata.Data8);
                return count;
            }
            function cloneTransformForSelected() {
                if (!state.selectedItem) { return; }
                let key = state.selectedItem.keyFrame;
                let oldId = key.TransformationId;
                let src = flpdata.Transformations[oldId];
                if (!src) { return; }
                flpdata.Transformations.push(JSON.parse(JSON.stringify(src)));
                key.TransformationId = flpdata.Transformations.length - 1;
                state.selectedItem.transformId = key.TransformationId;
                state.patchLog.push('clone transform ' + oldId + ' -> ' + key.TransformationId + ' for ' + state.selectedItem.id);
            }
            function ensureEditableTransformForSelected() {
                if (state.selectedItem && state.cloneTransformOnDrag && transformUsageCount(state.selectedItem.transformId) > 1) { cloneTransformForSelected(); }
            }
            function canvasToWorld(canvas, x, y) {
                let rect = canvas.getBoundingClientRect();
                let cx = (x - rect.left) * (canvas.width / rect.width);
                let cy = (y - rect.top) * (canvas.height / rect.height);
                let wx = (cx - canvas.width / 2) / state.zoom;
                let wy = (cy - canvas.height / 2) / state.zoom;
                if (state.invertY) { wy = -wy; }
                return { x: wx, y: wy };
            }
            function worldToCanvas(canvas, x, y) {
                let cy = state.invertY ? -y : y;
                return { x: canvas.width / 2 + x * state.zoom, y: canvas.height / 2 + cy * state.zoom };
            }
            function itemSize(it) {
                let t = it.elementHandler.TypeArrayId;
                if (t == 5) { return { w: 160, h: 28 }; }
                if (t == 4) { return { w: 130, h: 28 }; }
                if (t == 6 || t == 7 || t == 8) { return { w: 95, h: 34 }; }
                return { w: 70, h: 40 };
            }
            function hitTest(canvas, ev) {
                let rect = canvas.getBoundingClientRect();
                let x = (ev.clientX - rect.left) * (canvas.width / rect.width);
                let y = (ev.clientY - rect.top) * (canvas.height / rect.height);
                for (let i = state.visibleItems.length - 1; i >= 0; i--) {
                    let it = state.visibleItems[i];
                    let p = worldToCanvas(canvas, it.world.x, it.world.y);
                    let s = itemSize(it);
                    if (x >= p.x - s.w / 2 && x <= p.x + s.w / 2 && y >= p.y - s.h / 2 && y <= p.y + s.h / 2) { return it; }
                }
                return null;
            }
            function drawStage() {
                collectVisibleItems();
                let canvas = $('#flp-hud-stage')[0];
                if (!canvas) { return; }
                let ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.fillStyle = '#3c3f41';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.strokeStyle = 'rgba(255,0,0,.55)'; ctx.beginPath(); ctx.moveTo(0, canvas.height / 2); ctx.lineTo(canvas.width, canvas.height / 2); ctx.stroke();
                ctx.strokeStyle = 'rgba(0,255,80,.55)'; ctx.beginPath(); ctx.moveTo(canvas.width / 2, 0); ctx.lineTo(canvas.width / 2, canvas.height); ctx.stroke();
                ctx.font = '12px monospace'; ctx.textBaseline = 'top';
                for (let it of state.visibleItems) {
                    let p = worldToCanvas(canvas, it.world.x, it.world.y);
                    let sz = itemSize(it);
                    let rgba = 'rgba(' + Math.round(clamp(it.color[0], 0, 1) * 255) + ',' + Math.round(clamp(it.color[1], 0, 1) * 255) + ',' + Math.round(clamp(it.color[2], 0, 1) * 255) + ',' + clamp(it.color[3], 0.15, 1) + ')';
                    let selected = state.selectedKey == it.id;
                    ctx.save(); ctx.translate(p.x, p.y);
                    ctx.strokeStyle = selected ? '#ffff00' : 'rgba(255,255,255,.65)'; ctx.lineWidth = selected ? 3 : 1; ctx.fillStyle = rgba;
                    let img = getTextureImage(firstTextureNameForHandler(it.elementHandler));
                    if (img && img.complete && it.elementHandler.TypeArrayId == 1) { ctx.globalAlpha = clamp(it.color[3], 0.25, 1); ctx.drawImage(img, -sz.w / 2, -sz.h / 2, sz.w, sz.h); ctx.globalAlpha = 1; } else { ctx.fillRect(-sz.w / 2, -sz.h / 2, sz.w, sz.h); }
                    ctx.strokeRect(-sz.w / 2, -sz.h / 2, sz.w, sz.h);
                    ctx.fillStyle = selected ? '#ffff00' : '#ffffff'; ctx.fillText(it.label.substring(0, 32), -sz.w / 2 + 3, -sz.h / 2 + 3);
                    ctx.restore();
                }
                renderElementList(); renderInspector();
            }
            function renderElementList() {
                let list = $('#flp-hud-elements').empty();
                for (let it of state.visibleItems) {
                    let row = $('<div>').css({ padding: '4px', cursor: 'pointer', borderBottom: '1px solid #222', color: state.selectedKey == it.id ? '#ffff80' : '#ddd' });
                    row.text(it.id + ' | ' + it.label + ' | ' + transformName(it.transformId) + ' | ' + colorName(it.colorId));
                    row.click(function() { state.selectedKey = it.id; state.selectedItem = it; drawStage(); });
                    list.append(row);
                }
            }
            function renderInspector() {
                let box = $('#flp-hud-inspector').empty();
                if (!state.selectedItem) { box.text('Selecione um elemento no stage/lista.'); return; }
                let it = state.selectedItem, key = it.keyFrame;
                let tr = flpdata.Transformations[key.TransformationId];
                let col = flpdata.BlendColors[key.ColorId];
                function inputRow(label, input) { return $('<div>').css({ margin: '4px 0' }).append($('<label>').css({ display: 'inline-block', width: '130px' }).text(label), input); }
                box.append($('<h3>').text(it.label), $('<div>').text('Handler: ' + handlerName(key.ElementHandler)), $('<div>').text('Keyframe: ' + it.id), $('<div>').text('Uso do transform: ' + transformUsageCount(key.TransformationId) + ' keyframe(s)'));
                box.append(inputRow('Name', $('<input type="text">').val(key.Name || '').on('change', function() { key.Name = this.value; state.patchLog.push('set key name ' + it.id); })));
                box.append(inputRow('Frame end', $('<input type="number">').val(key.WhenThisFrameEnds).on('change', function() { key.WhenThisFrameEnds = Number.parseInt(this.value) || 0; state.patchLog.push('set frame end ' + it.id); drawStage(); })));
                box.append(inputRow('TransformId', $('<input type="number">').val(key.TransformationId).on('change', function() { key.TransformationId = clamp(Number.parseInt(this.value) || 0, 0, flpdata.Transformations.length - 1); state.patchLog.push('set transform id ' + it.id); drawStage(); })));
                box.append(inputRow('ColorId', $('<input type="number">').val(key.ColorId).on('change', function() { key.ColorId = clamp(Number.parseInt(this.value) || 0, 0, flpdata.BlendColors.length - 1); state.patchLog.push('set color id ' + it.id); drawStage(); })));
                if (tr) {
                    box.append(inputRow('OffsetX', $('<input type="number" step="0.0625">').val(tr.OffsetX).on('change', function() { tr.OffsetX = n(this.value, tr.OffsetX); state.patchLog.push('set OffsetX ' + key.TransformationId); drawStage(); })));
                    box.append(inputRow('OffsetY', $('<input type="number" step="0.0625">').val(tr.OffsetY).on('change', function() { tr.OffsetY = n(this.value, tr.OffsetY); state.patchLog.push('set OffsetY ' + key.TransformationId); drawStage(); })));
                    box.append(inputRow('Matrix[4]', $('<textarea>').css({ width: '95%', height: '70px' }).val(JSON.stringify(tr.Matrix)).on('change', function() { try { let m = JSON.parse(this.value); if (m.length == 4) { tr.Matrix = m.map(Number); state.patchLog.push('set matrix ' + key.TransformationId); drawStage(); } } catch (e) { alert('Matrix JSON inválida: ' + e); } })));
                    box.append($('<button>').text('Clone transform agora').click(function() { cloneTransformForSelected(); drawStage(); }));
                }
                if (col && col.Color) {
                    let colorLine = $('<div>').css({ marginTop: '8px' }).append('RGBA 0..256: ');
                    for (let i = 0; i < 4; i++) { colorLine.append($('<input type="number" min="0" max="256">').css({ width: '55px' }).val(col.Color[i]).on('change', function() { col.Color[i] = clamp(Number.parseInt(this.value) || 0, 0, 256); state.patchLog.push('set color ' + key.ColorId); drawStage(); })); }
                    box.append(colorLine);
                }
            }
            function collectScripts() {
                let out = [];
                function addScript(label, s) { if (s && s.Decompiled) { out.push({ label: label, script: s }); } }
                function scanSub1(prefix, node) {
                    if (!node || !node.FrameScriptLables) { return; }
                    for (let i = 0; i < node.FrameScriptLables.length; i++) {
                        let lbl = node.FrameScriptLables[i];
                        for (let j = 0; j < lbl.Subs.length; j++) { addScript(prefix + '.FrameScriptLables[' + i + '] ' + (lbl.LabelName || '') + '.Subs[' + j + ']', lbl.Subs[j].Script); }
                    }
                }
                for (let i = 0; i < flpdata.Datas6.length; i++) { scanSub1('Datas6[' + i + '].Sub1', flpdata.Datas6[i].Sub1); for (let j = 0; j < flpdata.Datas6[i].Sub2s.length; j++) { addScript('Datas6[' + i + '].Sub2s[' + j + '] event', flpdata.Datas6[i].Sub2s[j].Script); } }
                for (let i = 0; i < flpdata.Datas7.length; i++) { scanSub1('Datas7[' + i + ']', flpdata.Datas7[i]); }
                scanSub1('Data8 ROOT', flpdata.Data8);
                return out;
            }
            function renderScriptEditor(container) {
                container.empty();
                let scripts = collectScripts();
                let sel = $('<select>').css({ width: '100%' });
                for (let i = 0; i < scripts.length; i++) { sel.append($('<option>').val(i).text(i + ' | ' + scripts[i].label)); }
                let area = $('<textarea>').css({ width: '100%', height: '330px', fontFamily: 'monospace' });
                function load() { let s = scripts[Number.parseInt(sel.val())]; area.val(s ? s.script.Decompiled.join('\n') : ''); }
                sel.on('change', load);
                area.on('change', function() { let s = scripts[Number.parseInt(sel.val())]; if (s) { s.script.Decompiled = area.val().split(/\r?\n/).filter(x => x.trim().length); state.patchLog.push('edit script ' + s.label); } });
                let ops = $('<div>').css({ margin: '6px 0' });
                ['00: end', 'Play', 'Stop', 'GotoFrame ', 'GotoLabel ', 'CallFrame ', 'push_string ""'].forEach(function(op) { ops.append($('<button>').text(op).click(function() { area.val(area.val() + (area.val().endsWith('\n') ? '' : '\n') + op); area.trigger('change'); })); });
                container.append($('<h3>').text('Scripts / Decompiled opcodes'), sel, ops, area);
                load();
            }
            function renderDynamicLabels(container) {
                container.empty();
                let table = $('<table>').css({ width: '100%' });
                table.append($('<tr>').append('<th>ID</th><th>ValueName</th><th>Placeholder</th><th>FontHandler</th><th>Width1</th><th>BlendColor ARGB</th><th>Limit</th>'));
                for (let i = 0; i < flpdata.DynamicLabels.length; i++) {
                    let d = flpdata.DynamicLabels[i];
                    function inp(prop, width) { return $('<input>').css({ width: width || '120px' }).val(d[prop]).on('change', function() { d[prop] = (typeof d[prop] == 'number') ? Number.parseInt(this.value) || 0 : this.value; state.patchLog.push('edit DynamicLabels[' + i + '].' + prop); }); }
                    table.append($('<tr>').append($('<td>').text(i), $('<td>').append(inp('ValueName')), $('<td>').append(inp('Placeholder')), $('<td>').append(inp('FontHandler', '70px')), $('<td>').append(inp('Width1', '70px')), $('<td>').append(inp('BlendColor', '100px')), $('<td>').append(inp('StringLengthLimit', '70px'))));
                }
                container.append($('<h3>').text('DynamicLabels'), table);
            }
            function renderColors(container) {
                container.empty();
                let table = $('<table>').css({ width: '100%' });
                table.append($('<tr>').append('<th>ID</th><th>Preview</th><th>R</th><th>G</th><th>B</th><th>A</th>'));
                for (let i = 0; i < flpdata.BlendColors.length; i++) {
                    let c = flpdata.BlendColors[i];
                    let prev = $('<div>').css({ width: '36px', height: '18px', border: '1px solid #888', background: 'rgba(' + c.Color[0] / 256 * 255 + ',' + c.Color[1] / 256 * 255 + ',' + c.Color[2] / 256 * 255 + ',' + c.Color[3] / 256 + ')' });
                    let row = $('<tr>').append($('<td>').text(i), $('<td>').append(prev));
                    for (let k = 0; k < 4; k++) { row.append($('<td>').append($('<input type="number" min="0" max="256">').css({ width: '60px' }).val(c.Color[k]).on('change', function() { c.Color[k] = clamp(Number.parseInt(this.value) || 0, 0, 256); state.patchLog.push('edit BlendColors[' + i + ']'); renderColors(container); drawStage(); }))); }
                    table.append(row);
                }
                container.append($('<h3>').text('BlendColors'), table);
            }
            function validateFlp() {
                let problems = [];
                function checkHandler(h, where) {
                    if (!h) { problems.push(where + ': handler vazio'); return; }
                    if (h.TypeArrayId == 8) { return; }
                    let arr = get_obj_arr_by_id(h.TypeArrayId);
                    if (!arr) { problems.push(where + ': TypeArrayId desconhecido ' + h.TypeArrayId); return; }
                    if (h.IdInThatTypeArray < 0 || h.IdInThatTypeArray >= arr.length) { problems.push(where + ': IdInThatTypeArray fora do limite ' + h.IdInThatTypeArray); }
                }
                function scanNode(prefix, node) {
                    if (!node || !node.ElementsAnimation) { return; }
                    for (let i = 0; i < node.ElementsAnimation.length; i++) { let anim = node.ElementsAnimation[i]; for (let j = 0; j < anim.KeyFrames.length; j++) { let k = anim.KeyFrames[j]; checkHandler(k.ElementHandler, prefix + '.ElementsAnimation[' + i + '].KeyFrames[' + j + ']'); if (k.TransformationId >= flpdata.Transformations.length) { problems.push(prefix + ' keyframe transform fora do limite: ' + k.TransformationId); } if (k.ColorId >= flpdata.BlendColors.length) { problems.push(prefix + ' keyframe color fora do limite: ' + k.ColorId); } } }
                }
                for (let i = 0; i < flpdata.GlobalHandlersIndexes.length; i++) { checkHandler(flpdata.GlobalHandlersIndexes[i], 'GlobalHandlersIndexes[' + i + ']'); }
                for (let i = 0; i < flpdata.Datas6.length; i++) { scanNode('Datas6[' + i + '].Sub1', flpdata.Datas6[i].Sub1); }
                for (let i = 0; i < flpdata.Datas7.length; i++) { scanNode('Datas7[' + i + ']', flpdata.Datas7[i]); }
                scanNode('Data8', flpdata.Data8);
                for (let s of collectScripts()) { let lines = s.script.Decompiled || []; if (!lines.length || !String(lines[lines.length - 1]).toLowerCase().includes('end')) { problems.push('Script talvez sem end: ' + s.label); } }
                return problems;
            }
            function downloadEditedJson() {
                let blob = new Blob([JSON.stringify(flpdata, null, 2)], { type: 'application/json' });
                let a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'FLP_edited.json'; a.click(); setTimeout(function() { URL.revokeObjectURL(a.href); }, 500);
            }
            function uploadEditedJson() {
                if (!confirm('Enviar JSON editado para fromjson e repackar o FLP no WAD? Faça backup antes.')) { return; }
                let fd = new FormData();
                fd.append('data', new Blob([JSON.stringify(flpdata, null, 2)], { type: 'application/json' }), 'FLP_edited.json');
                $.ajax({ url: getActionLinkForWadNode(wad, tagid, 'fromjson'), method: 'POST', data: fd, processData: false, contentType: false, success: function(a) { if (a != '' && a.error) { alert('Erro no fromjson: ' + a.error); } else { alert('FLP atualizado com sucesso. Reabra o node para recarregar.'); } }, error: function(xhr) { alert('Falha HTTP: ' + xhr.status + ' ' + xhr.responseText); } });
            }

            let root = $('<div id="flp-hud-editor">').css({ display: 'grid', gridTemplateColumns: 'minmax(600px, 1fr) 430px', gap: '8px', padding: '6px' });
            let left = $('<div>'); let right = $('<div>').css({ maxHeight: '76vh', overflow: 'auto' }); let toolbar = $('<div>').css({ marginBottom: '6px' });
            let timelineSel = $('<select>');
            for (let o of timelineOptions()) { timelineSel.append($('<option>').val(o.id).text(o.label)); }
            let frameSlider = $('<input type="range" min="0" value="0">').css({ width: '220px' }).on('input', function() { state.frame = Number.parseInt(this.value) || 0; $('#flp-hud-frame-label').text(state.frame); drawStage(); });
            function updateFrameMax() { let tl = currentTimeline(); let max = tl.node && tl.node.TotalFramesCount ? tl.node.TotalFramesCount - 1 : 0; frameSlider.attr('max', Math.max(0, max)); }
            timelineSel.val(state.timeline).on('change', function() { state.timeline = this.value; state.frame = 0; frameSlider.val(0); updateFrameMax(); drawStage(); });
            let zoomInput = $('<input type="number" step="0.1" min="0.1">').css({ width: '70px' }).val(state.zoom).on('change', function() { state.zoom = Math.max(0.1, n(this.value, 1)); drawStage(); });
            let cloneCheck = $('<input type="checkbox">').prop('checked', state.cloneTransformOnDrag).on('change', function() { state.cloneTransformOnDrag = this.checked; });
            let invertCheck = $('<input type="checkbox">').prop('checked', state.invertY).on('change', function() { state.invertY = this.checked; drawStage(); });
            toolbar.append('Timeline ', timelineSel, ' Frame ', frameSlider, ' <span id="flp-hud-frame-label">0</span> ', ' Zoom ', zoomInput, $('<label>').append(cloneCheck, ' clone transform ao arrastar'), $('<label>').css({ marginLeft: '8px' }).append(invertCheck, ' inverter Y'));
            let canvas = $('<canvas id="flp-hud-stage" width="960" height="540">').css({ width: '100%', border: '1px solid #111', background: '#3c3f41', cursor: 'crosshair' });
            canvas.on('mousedown', function(ev) { let it = hitTest(this, ev); if (!it) { return; } state.selectedKey = it.id; state.selectedItem = it; ensureEditableTransformForSelected(); let p = canvasToWorld(this, ev.clientX, ev.clientY); let tr = flpdata.Transformations[state.selectedItem.keyFrame.TransformationId]; state.drag = { start: p, origX: tr.OffsetX, origY: tr.OffsetY }; drawStage(); });
            canvas.on('mousemove', function(ev) { if (!state.drag || !state.selectedItem) { return; } let p = canvasToWorld(this, ev.clientX, ev.clientY); let tr = flpdata.Transformations[state.selectedItem.keyFrame.TransformationId]; tr.OffsetX = state.drag.origX + (p.x - state.drag.start.x); tr.OffsetY = state.drag.origY + (p.y - state.drag.start.y); drawStage(); });
            $(document).on('mouseup.flphud', function() { if (state.drag && state.selectedItem) { state.patchLog.push('drag ' + state.selectedItem.id); } state.drag = null; });
            let tabs = $('<div>').css({ marginTop: '6px' }); let content = $('<div>').css({ border: '1px solid #333', padding: '6px', minHeight: '160px' });
            function tabButton(name, fn) { return $('<button>').text(name).click(function() { content.empty(); fn(content); }); }
            tabs.append(tabButton('Scripts', renderScriptEditor), tabButton('DynamicLabels', renderDynamicLabels), tabButton('BlendColors', renderColors), $('<button>').text('Validate').click(function() { let p = validateFlp(); content.empty().append($('<h3>').text('Validation'), $('<pre>').text(p.length ? p.join('\n') : 'OK - nenhum problema básico encontrado.')); }), $('<button>').text('Download edited FLP JSON').click(downloadEditedJson), $('<button>').text('Upload edited FLP JSON to WAD').click(uploadEditedJson), $('<button>').text('Render timeline no viewer 3D').click(function() { object_renderer_handler = currentTimeline().handler; flp_view_object_renderer(); }));
            left.append(toolbar, canvas, $('<h3>').text('Elementos visíveis'), $('<div id="flp-hud-elements">').css({ maxHeight: '180px', overflow: 'auto', border: '1px solid #222' }), tabs, content);
            right.append($('<h3>').text('Inspector'), $('<div id="flp-hud-inspector">'));
            root.append(left, right); dataSummary.append(root); updateFrameMax(); drawStage();
        }
