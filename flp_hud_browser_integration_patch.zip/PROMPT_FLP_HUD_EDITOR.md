# Prompt técnico — integrar editor FLP/HUD no God of War Browser

Atue como desenvolvedor sênior Go + JavaScript especializado no God of War Browser e nos formatos FLP/MDL/TXR de God of War 1/2.

Contexto:
- Repositório alvo: `https://github.com/leonifc331/god_of_war_browser`.
- O Browser já possui parser FLP em `pack/wad/flp/`, ações HTTP em `actions.go`, marshal/repack em `marshal.go`, renderizador FLP em `web/data/static/js/BrowserWadFlp.js` e rotas WAD em `web/server.go` / `web/handlers.go`.
- O objetivo é transformar a edição de `FLP_HUDA` em um editor visual integrado, aproveitando o JSON FLP já marshalado pelo Browser e as ações existentes `asjson`, `fromjson`, `transform`, `staticlabels`, `exportfont` e `replacefont`.

Tarefa:
1. Adicionar uma nova aba chamada `HUD editor` dentro de `summaryLoadWadFlp(flp, wad, tagid)` em `BrowserWadFlp.js`.
2. O editor precisa trabalhar sobre `flp.FLP`, sem alterar arrays fora de ordem.
3. Implementar:
   - Stage 2D aproximado para `Data8`, `Datas7` e `Datas6[x].Sub1`.
   - Seletor de timeline/root.
   - Slider de frame.
   - Coleta recursiva de keyframes visíveis no frame atual.
   - Resolução legível de `ElementHandler.TypeArrayId + IdInThatTypeArray`.
   - Lista de elementos visíveis.
   - Seleção de elemento.
   - Arrastar elemento para editar `Transformations[TransformationId].OffsetX/Y`.
   - Opção `clone transform antes de mover` para evitar editar transforms compartilhados.
   - Inspector com `OffsetX`, `OffsetY`, `Matrix`, `TransformationId`, `ColorId`, nome do keyframe e handler resolvido.
   - Editor de `DynamicLabels`.
   - Editor de `BlendColors`.
   - Editor de scripts baseado em `Script.Decompiled`.
   - Validação de handlers, transform IDs, color IDs e scripts sem `end`.
   - Exportar JSON FLP editado.
   - Enviar JSON editado para `fromjson` usando `FormData`, permitindo o Browser recompilar scripts e repackar o FLP.
4. Não implementar recompilação manual em JavaScript; usar a ação Go existente `fromjson`, porque `pack/wad/flp/actions.go` já chama `Script.FromDecompiled()` e `marshalBufferWithHeader()`.
5. Não alterar a estrutura binária diretamente no frontend.
6. Manter compatibilidade com o estilo antigo do Browser: jQuery, `let/const`, sem framework novo.
7. A primeira versão deve ser segura: editar offsets, matrix, cores, labels e scripts, mas não deletar arrays nem renumerar handlers.

Critérios de aceitação:
- Ao abrir um recurso `FLP_`, aparece a aba `HUD editor`.
- É possível escolher `ROOT Data8`, `Datas7[n]` ou `Datas6[n].Sub1`.
- O stage mostra os elementos visíveis do frame atual.
- Clicar em um elemento mostra o inspector.
- Arrastar altera offsets e atualiza o stage.
- `Validate` mostra problemas sem travar.
- `Download edited FLP JSON` baixa apenas o objeto `FLP`, compatível com `fromjson`.
- `Upload edited FLP JSON to WAD` envia para `/action/{file}/{tagid}/fromjson` e o backend repacka.
- Nenhuma mudança deve quebrar as abas antigas: `Labels editor`, `Dump`, `Font viewer`, `Obj explorer`, `Obj renderer`.
