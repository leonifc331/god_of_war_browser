# FLP/HUD Editor — integração inicial para o God of War Browser

Este pacote contém um patch inicial para adicionar uma aba **HUD editor** ao `BrowserWadFlp.js`.

## Arquivos

- `PROMPT_FLP_HUD_EDITOR.md` — prompt técnico usado como especificação.
- `BrowserWadFlp_HUD_EDITOR_INSERT.js` — bloco JS completo para revisão/manual paste.
- `0001-add-flp-hud-editor.patch` — patch para aplicar no fork.

## Como aplicar

Na raiz do seu fork:

```bash
git checkout -b flp-hud-editor
git apply 0001-add-flp-hud-editor.patch
```

Se o `git apply` falhar por diferença de contexto, abra `web/data/static/js/BrowserWadFlp.js` e faça manualmente:

1. Procure o final da função `flp_view_object_renderer`, logo antes das linhas:

```js
dataSummarySelectors.append($('<div class="item-selector">').click(flp_list_labels).text("Labels editor"));
```

2. Cole todo o conteúdo de `BrowserWadFlp_HUD_EDITOR_INSERT.js` antes dessas linhas.
3. Logo abaixo, adicione:

```js
dataSummarySelectors.append($('<div class="item-selector">').click(flp_hud_stage_editor).text("HUD editor"));
```

## Como testar

Execute o Browser normalmente, por exemplo:

```bash
go run god_of_war_browser.go -dir "I:\Jogos ps2\...\WAD" -ps ps2 -gowversion 2
```

Abra no navegador:

```text
http://127.0.0.1:8000/
```

Selecione `R_PERMA.WAD`, abra `FLP_HUDA` e clique em **HUD editor**.

## Recursos implementados

- Stage 2D aproximado para `Data8`, `Datas7` e `Datas6[x].Sub1`.
- Slider de frame.
- Lista de elementos visíveis.
- Inspector de keyframe.
- Drag-and-drop para `Transformations[TransformationId].OffsetX/Y`.
- Clone automático de transform compartilhado.
- Edição de `Matrix`, `ColorId`, `TransformationId`, nome e frame end.
- Editor de `DynamicLabels`.
- Editor de `BlendColors`.
- Editor textual de `Script.Decompiled`.
- Validador básico.
- Export JSON compatível com `fromjson`.
- Upload para `/action/{file}/{tagid}/fromjson` usando `FormData`.

## Observações

O stage é aproximado porque ele não calcula a silhueta real da mesh/UV. Para preview fiel, use o botão **Render timeline no viewer 3D**, que reaproveita o renderizador FLP existente do Browser.

A edição de script é feita em `Script.Decompiled`; a recompilação é feita pelo backend Go através da ação `fromjson`, que já chama `Script.FromDecompiled()` antes de gerar o FLP binário.
