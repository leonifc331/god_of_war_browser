# Próximos passos recomendados

1. Trocar o stage aproximado por picking no renderer 3D real.
2. Criar ação Go `hudpatch` para aplicar patches granulares, evitando upload do JSON inteiro.
3. Adicionar `Validate()` no pacote `pack/wad/flp`, com validação também no backend.
4. Adicionar nomes semânticos por heurística: life bar, mana bar, orb counter, item icon etc.
5. Adicionar busca por textura/material e vínculo direto com `MDL_`/`TXR_`.
6. Adicionar botão de backup automático antes de `fromjson`.
7. Criar modo diff: original FLP vs editado.
