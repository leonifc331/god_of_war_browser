# God of War Browser — pacote full frontend upgrade

Este pacote melhora todos os arquivos de frontend enviados: interface, renderer, helpers, animação, status, WAD viewer, FLP/HUD editor e label viewer.

## Principais melhorias

- Interface geral modernizada em `style.css`: painéis, tabelas, filtros, botões, barras, status e editor FLP/HUD.
- `Renderer.js`: WebGL com antialias/HiDPI/preserveDrawingBuffer, cor de fundo, screenshot PNG, reset de câmera, grid, auto-rotação, controle de textura e injeção automática de uniforms comuns de iluminação em shaders.
- `RendererHelpers.js`: grid, vetor de luz, bounding helpers e esferas coloridas para entidades/scripts.
- `Browser.js`: painel Render Pro, filtros automáticos em tabelas, atalhos R/P/G/C/Espaço, controles de luz/ambiente/exposição/gamma.
- `Animation.js`: pausa, step, velocidade global e mini painel de animação.
- `BrowserWad.js`: ativa visualização de esferas para `SCR_Entities`, ativa `SCR_AresSky` como sky e adiciona helpers de resumo.
- `BrowserWadFlp.js`: mantém o editor HUD/FLP Pro e adiciona utilitários de validação/resolução de handlers.
- `Status.js`: WebSocket compatível com HTTPS, reconexão com backoff e indicador online/offline.
- `LabelViewer.js`: toolbar para reset de câmera, HiDPI e captura PNG.

## Como aplicar no fork

Na raiz do repositório:

```bash
cp -r web/data/static/* ./web/data/static/
git add web/data/static/style.css web/data/static/js/*.js
git commit -m "Improve GoW Browser frontend renderer UI and editors"
git push origin master
```

Ou copie arquivo por arquivo para:

```txt
web/data/static/style.css
web/data/static/js/Animation.js
web/data/static/js/Browser.js
web/data/static/js/BrowserWad.js
web/data/static/js/BrowserWadFlp.js
web/data/static/js/LabelViewer.js
web/data/static/js/Renderer.js
web/data/static/js/RendererHelpers.js
web/data/static/js/Status.js
```

## Atalhos novos

- `R`: reset da câmera
- `P`: captura PNG do viewer
- `G`: liga/desliga grid
- `C`: backface culling
- `Espaço`: pausa/continua animação

## Observação

Os arquivos vendor minificados (`jquery`, `gl-matrix`, plugins jQuery) foram deixados intactos de propósito. Alterar bibliotecas vendor minificadas dificulta debug e pode criar regressões.
